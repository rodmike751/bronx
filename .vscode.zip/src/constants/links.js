/* eslint-disable prettier/prettier */

export const account_link = "https://hasthemes.com/account/";
