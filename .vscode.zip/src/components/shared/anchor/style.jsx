import styled from "@theme/utils";
import { Link } from "gatsby";

export const LinkWrapper = styled(Link)``;

export const AnchorTag = styled.a``;
